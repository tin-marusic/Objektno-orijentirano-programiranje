<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.4" tiledversion="1.4.2" name="spike" tilewidth="164" tileheight="160" tilecount="1" columns="0" objectalignment="topleft">
 <grid orientation="orthogonal" width="1" height="1"/>
 <tile id="0">
  <image width="164" height="160" source="spikes.png"/>
 </tile>
</tileset>
