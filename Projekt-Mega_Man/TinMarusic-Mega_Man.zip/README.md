# Vježbe 05

* nasljeđivanje
* kolizije

## Izmjene u okviru

### tiled.js

* promijenjeno: gravity i friction
* pripadaju klasi WorldMap kao svojstva koja su najprije postavljena na 2 i 0.8, redom

